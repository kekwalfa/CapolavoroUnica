<?php include 'verifica-loggato.php';?>

<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Ospedale | Profilo utente</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' href='css/main-riservato.css'>
    <link rel="stylesheet" href="css/profilo.css">
</head>
<body>
    
</body>
</html>