<ul>
    <a href="index.php"><li>HOME</li></a>
    <a href="accesso.php"><li>ACCEDI</li></a>
    <a href="registrazione.php"><li>REGISTRATI</li></a>
</ul>