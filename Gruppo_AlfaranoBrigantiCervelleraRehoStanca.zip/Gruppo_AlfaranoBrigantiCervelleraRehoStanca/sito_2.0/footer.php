<div>
    <p><b>ALTRO</b></p>
    <ul>
        <li><a href="pagina-in-sviluppo.php" target="_blank">Chi siamo</a></li>
        <li><a href="pagina-in-sviluppo.php" target="_blank">Organigramma</a></li>
        <li><a href="https://maps.google.it" target="_blank">Dove siamo</a></li>
        <li><a href="pagina-in-sviluppo.php" target="_blank">Reparti</a></li>
        <li><a href="pagina-in-sviluppo.php" target="_blank">Privacy</a></li>
    </ul>
</div>

<div>
    <p><b>CONTATTI</b></p>
    <ul>
        <li>0833 912152</li>
        <li>aiuto@ospedale.com</li>
    </ul>
</div>

<div>
    <p><b>SOCIAL</b></p>
    <ul>
        <li><a href="https://www.facebook.com" target="_blank">Facebook</a></li>
        <li><a href="https://www.x.com" target="_blank">Twitter</a></li>
        <li><a href="https://web.whatsapp.com" target="_blank">Whatsapp</a></li>
        <li><a href="https://web.telegram.org" target="_blank">Telegram</a></li>
        <li><a href="https://www.instagram.com" target="_blank">Instagram</a></li>
    </ul>
    
</div>