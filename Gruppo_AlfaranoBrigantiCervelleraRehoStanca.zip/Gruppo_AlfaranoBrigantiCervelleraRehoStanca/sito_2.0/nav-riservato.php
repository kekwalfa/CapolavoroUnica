<ul>
    <a href="index.php"><li>HOME</li></a>
    <a href="area-riservata-paziente.php"><li>AREA RISERVATA</li></a>
    <a href="profilo.php"><li>PROFILO</li></a>
    <a href="esci.php"><li>ESCI</li></a>
</ul>